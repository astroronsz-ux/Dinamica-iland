# Dynamic Pill — Dynamic-Island-style overlay for Android (Redmi Note 10 Pro / MIUI)

Kotlin + Jetpack Compose, no root, no ROM mod. Single APK (~3 MB release).

## How it works
| Piece | What it does | Permission / access |
|---|---|---|
| `IslandAccessibilityService` | Draws the pill in a `TYPE_ACCESSIBILITY_OVERLAY` window right on the camera cut-out; swipe-down on it opens the notification shade; also listens to battery + Bluetooth broadcasts | Accessibility service (enabled by you). `canRetrieveWindowContent=false` → it cannot read your screen. **No "draw over other apps" permission needed.** |
| `IslandNotificationListener` | Notifications (with actions + inline reply + dismiss), calls (via the dialer's notification buttons), alarms, timers/stopwatch, navigation, music sessions (play/pause/next/prev) | Notification access (enabled by you) |
| `GeminiClient` | Typed questions to Gemini through the Google AI Studio REST API, answer shown inside the island | `INTERNET` (only used for this) |
| Bluetooth events | Name of the device that (dis)connects | `BLUETOOTH_CONNECT` (Android 12+) |
| `BootReceiver` | Asks MIUI to re-bind the listener after boot / update | `RECEIVE_BOOT_COMPLETED` |

Touch safety: the overlay window is exactly the size of the pill (1×1 px and non-touchable when hidden), and only grows while the island is expanded, so the status bar, quick-settings pull-down and notch area keep working. Swiping down on the idle/compact pill forwards to the real notification shade.

Low resource use: no foreground service, no polling, no wake-locks. Events come from system callbacks; Compose animations and the 1 s timer tick only run while something is visible; the hidden state is a 1×1 px window.

## Using it
* Idle pill (optional): tap → ask Gemini by keyboard, long-press → voice assistant (Gemini/Google Assistant), swipe down → notification shade.
* Compact pill appears on any event; tap to expand; swipe up / ✕ / tap outside / timeout to close.
* Calls and alarms auto-expand and stay until handled.

## Gemini — what is and isn't possible
Google offers no public API for third-party apps to drive the Gemini app or read its answers. This project therefore does two things: (1) text questions via the official Gemini REST API using **your own free API key** (aistudio.google.com/apikey) — the model name is editable in Settings because model names change over time; (2) long-press launches your default assistant (Gemini if you set it) via `ACTION_ASSIST` for voice. The "Ask Gemini" chip on a notification sends that notification's text to Google only when you tap it. The key is stored in app-private SharedPreferences (not encrypted).

## Build
1. Install **Android Studio** (Koala 2024.1.1 or newer; bundled JDK 17) and let it install the Android SDK Platform 34.
2. *File → Open…* → select the `DynamicPill` folder → wait for the Gradle sync (downloads Gradle 8.9 automatically).
3. Debug APK: *Build → Build Bundle(s)/APK(s) → Build APK(s)* → `app/build/outputs/apk/debug/app-debug.apk`.
   Release APK (smaller/faster, signed with the debug key so it installs): *Build → Select Build Variant → release*, then build; or in a terminal `gradle wrapper --gradle-version 8.9` once, then `./gradlew assembleRelease`.

## Install on the Redmi Note 10 Pro
**A. USB (recommended)**
1. Phone: *Settings → About phone* → tap **MIUI version** 7×.
2. *Settings → Additional settings → Developer options* → enable **USB debugging** and **Install via USB** (MIUI asks you to sign in to a Mi account / have data for this toggle).
3. Plug in, set USB mode to *File transfer*, accept the RSA prompt.
4. Android Studio: pick the phone in the device list → ▶ Run. (Or `adb install -r app-debug.apk`.)

**B. Copy the APK**
Send `app-debug.apk` to the phone (cable, Telegram, Drive), open it with the file manager, allow "Install unknown apps" for that app when asked, tap Install (dismiss MIUI's security-scan prompts).

## First-run setup (do all of it — MIUI is aggressive)
1. Open **Dynamic Pill**; the *Setup* card shows ✓/✗ for each item.
2. **Accessibility service**: Enable → *Downloaded apps* → Dynamic Pill → On. If the switch is greyed out on Android 13 / MIUI 14: *App info → ⋮ → Allow restricted settings*, then try again.
3. **Notification access**: Enable → Dynamic Pill → On.
4. **Bluetooth permission**: Grant ("Nearby devices").
5. **Battery**: Allow (or *Security → Battery → App battery saver → Dynamic Pill → No restrictions*).
6. **MIUI buttons** (shown on Xiaomi phones): *Autostart* → On; *Other permissions → Display pop-up windows while running in the background* → Allow (needed so tapping the island can open apps/Gemini from the background); lock the app in **Recents** (long-press its card → lock icon).
7. Press the *Try it* buttons to see each event type.

## Known limits (honest list)
* Written without access to a device or Android SDK in this environment: it has **not been compiled or run here**. Expect to fix small compile errors or version mismatches on first sync; the structure is conventional.
* Accessibility overlays may not draw over the lock screen on all MIUI builds, and the pill is hidden in landscape by design.
* Calls: answer/decline works only if the dialer's notification exposes those actions (MIUI/Google Dialer do). Timers/alarms depend on the clock app posting an ongoing chronometer / alarm-category notification.
* Navigation shows the text of the Maps notification (instruction + distance/ETA), not a map.
* Bluetooth battery level of headphones is not exposed by a public API, so it isn't shown.
* Visuals are drawn in code (no Apple assets); the pill is just a rounded surface shaped around your camera hole.

## Project map
`Model.kt` events, settings, event bus · `Ui.kt` Compose island (compact/expanded, icons, Gemini panel) · `IslandAccessibilityService.kt` overlay window, cut-out geometry, battery/Bluetooth · `IslandNotificationListener.kt` notifications/media · `GeminiClient.kt` · `MainActivity.kt` setup + customisation · `Miui.kt` Xiaomi shortcuts.
