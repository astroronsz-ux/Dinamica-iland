package com.example.dynamicpill

import android.app.Notification
import android.app.RemoteInput
import android.content.ComponentName
import android.content.Intent
import android.graphics.Bitmap
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSession
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.Bundle
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import androidx.core.graphics.drawable.toBitmap

/**
 * One listener covers: notifications, incoming/ongoing calls, alarms, timers, navigation and music.
 * Calls are handled through the dialer's own notification actions, so no phone permission is needed.
 */
class IslandNotificationListener : NotificationListenerService() {

    private val comp by lazy { ComponentName(this, IslandNotificationListener::class.java) }
    private val controllers = HashMap<MediaSession.Token, MediaController>()

    private val cb = object : MediaController.Callback() {
        override fun onPlaybackStateChanged(state: PlaybackState?) = refreshMedia()
        override fun onMetadataChanged(metadata: MediaMetadata?) = refreshMedia()
        override fun onSessionDestroyed() = refreshMedia()
    }
    private val sessionsListener = MediaSessionManager.OnActiveSessionsChangedListener { sync(it) }

    override fun onListenerConnected() {
        try {
            val msm = getSystemService(MediaSessionManager::class.java)
            msm.addOnActiveSessionsChangedListener(sessionsListener, comp)
            sync(msm.getActiveSessions(comp))
        } catch (_: SecurityException) {
        }
        try { activeNotifications?.forEach { handle(it, true) } } catch (_: Exception) {}
    }

    override fun onListenerDisconnected() {
        try { getSystemService(MediaSessionManager::class.java).removeOnActiveSessionsChangedListener(sessionsListener) } catch (_: Exception) {}
        controllers.values.forEach { it.unregisterCallback(cb) }
        controllers.clear()
        IslandBus.remove("media")
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) = handle(sbn, false)
    override fun onNotificationRemoved(sbn: StatusBarNotification) = IslandBus.remove("n:${sbn.key}")

    // ---------------------------------------------------------------- notifications

    private fun handle(sbn: StatusBarNotification, initial: Boolean) {
        val s = Prefs.settings.value
        if (sbn.packageName == packageName || sbn.packageName in s.blocked) return
        val n = sbn.notification
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return
        val ex = n.extras
        val title = ex.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val text = (ex.getCharSequence(Notification.EXTRA_BIG_TEXT) ?: ex.getCharSequence(Notification.EXTRA_TEXT))?.toString().orEmpty()
        val ongoing = n.flags and Notification.FLAG_ONGOING_EVENT != 0
        val chrono = ex.getBoolean(Notification.EXTRA_SHOW_CHRONOMETER)
        val cat = n.category

        val kind = when {
            cat == Notification.CATEGORY_CALL -> Kind.CALL
            cat == Notification.CATEGORY_ALARM -> Kind.ALARM
            cat == Notification.CATEGORY_NAVIGATION -> Kind.NAVIGATION
            cat == "stopwatch" || (ongoing && chrono) -> Kind.TIMER
            cat == Notification.CATEGORY_TRANSPORT || cat == Notification.CATEGORY_PROGRESS ||
                cat == Notification.CATEGORY_SERVICE || cat == Notification.CATEGORY_SYSTEM ||
                cat == Notification.CATEGORY_STATUS -> return
            ongoing -> return
            else -> Kind.NOTIFICATION
        }
        if (initial && kind == Kind.NOTIFICATION) return          // don't replay old notifications on (re)connect
        if (title.isBlank() && text.isBlank()) return

        val app = appLabel(sbn)
        val (icon, mono) = iconOf(sbn)
        val actions = mutableListOf<EventAction>()
        var reply: ((String) -> Unit)? = null
        n.actions?.take(3)?.forEach { a ->
            val ri = a.remoteInputs?.firstOrNull { it.allowFreeFormInput }
            val label = a.title?.toString().orEmpty()
            if (ri != null) {
                reply = { msg -> sendReply(a, ri, msg) }
            } else if (a.actionIntent != null && label.isNotBlank()) {
                actions += EventAction(label = label, style = styleFor(label)) { sendPi(this, a.actionIntent) }
            }
        }
        val incoming = kind == Kind.CALL && !chrono
        IslandBus.post(
            IslandEvent(
                id = "n:${sbn.key}", kind = kind,
                title = title.ifBlank { app },
                text = when {
                    kind == Kind.CALL && text.isBlank() -> if (incoming) "Incoming call" else "Ongoing call"
                    else -> text
                },
                compact = when (kind) {
                    Kind.CALL -> if (incoming) "Calling" else "On call"
                    Kind.NAVIGATION -> text.ifBlank { title }
                    else -> title.ifBlank { app }
                },
                icon = icon, iconMono = mono,
                ttlMs = if (kind == Kind.NOTIFICATION) 7000L else 0L,
                autoExpand = incoming || kind == Kind.ALARM,
                actions = actions, reply = reply,
                open = { sendPi(this, n.contentIntent) },
                dismiss = { cancelNotification(sbn.key) },
                chronoWhen = if (chrono) n.`when` else 0L,
                chronoDown = ex.getBoolean("android.chronometerCountDown"),
                sourceApp = app
            )
        )
    }

    private fun styleFor(label: String): Style {
        val l = label.lowercase()
        return when {
            Regex("decline|reject|hang|end|dismiss|ignore|rifiut|termin|chiud|ignor|stop|cancel").containsMatchIn(l) -> Style.DESTRUCTIVE
            Regex("answer|accept|rispond|accett").containsMatchIn(l) -> Style.POSITIVE
            else -> Style.NEUTRAL
        }
    }

    private fun sendReply(a: Notification.Action, ri: RemoteInput, msg: String) {
        val intent = Intent().addFlags(Intent.FLAG_RECEIVER_FOREGROUND)
        RemoteInput.addResultsToIntent(a.remoteInputs, intent, Bundle().apply { putCharSequence(ri.resultKey, msg) })
        sendPi(this, a.actionIntent, intent)
    }

    private fun appLabel(sbn: StatusBarNotification): String = try {
        val c = sbn.getPackageContext(this)
        c.packageManager.getApplicationLabel(c.applicationInfo).toString()
    } catch (_: Exception) { sbn.packageName.substringAfterLast('.') }

    /** Returns (bitmap, isMonochromeSmallIcon). Uses only the notification's own icons, so no package-visibility permission. */
    private fun iconOf(sbn: StatusBarNotification): Pair<Bitmap?, Boolean> {
        val n = sbn.notification
        try {
            n.getLargeIcon()?.loadDrawable(this)?.toBitmap(96, 96)?.let { return it to false }
            n.smallIcon?.loadDrawable(sbn.getPackageContext(this))?.toBitmap(64, 64)?.let { return it to true }
        } catch (_: Exception) {
        }
        return null to false
    }

    // ---------------------------------------------------------------- music

    private fun sync(list: List<MediaController>?) {
        val fresh = list.orEmpty().associateBy { it.sessionToken }
        controllers.filterKeys { it !in fresh }.values.forEach { it.unregisterCallback(cb) }
        fresh.filterKeys { it !in controllers }.values.forEach { it.registerCallback(cb) }
        controllers.clear(); controllers.putAll(fresh)
        refreshMedia()
    }

    private fun refreshMedia() {
        val all = controllers.values
        val c = all.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING }
            ?: all.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PAUSED }
        val md = c?.metadata
        val title = md?.getString(MediaMetadata.METADATA_KEY_TITLE)
        if (c == null || md == null || title.isNullOrBlank()) { IslandBus.remove("media"); return }
        val playing = c.playbackState?.state == PlaybackState.STATE_PLAYING
        val art = md.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART) ?: md.getBitmap(MediaMetadata.METADATA_KEY_ART)
            ?: md.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON)
        val tc = c.transportControls
        IslandBus.post(
            IslandEvent(
                id = "media", kind = Kind.MEDIA, title = title,
                text = md.getString(MediaMetadata.METADATA_KEY_ARTIST) ?: md.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST) ?: "",
                compact = if (playing) "" else "Paused",
                icon = art?.let { Bitmap.createScaledBitmap(it, 128, 128, true) },
                playing = playing, ttlMs = if (playing) 0L else 8000L,
                actions = listOf(
                    EventAction(glyph = Glyph.PREV) { tc.skipToPrevious() },
                    EventAction(glyph = if (playing) Glyph.PAUSE else Glyph.PLAY) { if (playing) tc.pause() else tc.play() },
                    EventAction(glyph = Glyph.NEXT) { tc.skipToNext() }
                )
            )
        )
    }
}
