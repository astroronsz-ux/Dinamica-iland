package com.example.dynamicpill

import android.Manifest
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat

object Setup {
    fun a11y(ctx: Context): Boolean {
        val v = Settings.Secure.getString(ctx.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        val id = ComponentName(ctx, IslandAccessibilityService::class.java).flattenToString()
        return v.split(':').any { it.equals(id, true) }
    }
    fun notif(ctx: Context) = NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName)
    fun bt(ctx: Context) = Build.VERSION.SDK_INT < 31 ||
        ContextCompat.checkSelfPermission(ctx, Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED
    fun battery(ctx: Context) = ctx.getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(ctx.packageName)
    fun open(ctx: Context, action: String) {
        try { ctx.startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) { Miui.appInfo(ctx) }
    }
}

class MainActivity : ComponentActivity() {
    private var tick by mutableIntStateOf(0)
    private val btPerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) { tick++ }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val orange = Color(0xFFFF6900)
            MaterialTheme(colorScheme = if (isSystemInDarkTheme()) darkColorScheme(primary = orange) else lightColorScheme(primary = orange)) {
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    SettingsScreen(tick) { btPerm.launch(Manifest.permission.BLUETOOTH_CONNECT) }
                }
            }
        }
    }

    override fun onResume() { super.onResume(); tick++ }
}

@Composable
private fun Section(title: String, content: @Composable ColumnScope.() -> Unit) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            content()
        }
    }
}

@Composable
private fun SetupRow(title: String, desc: String, ok: Boolean, button: String, onClick: () -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text((if (ok) "✓ " else "✗ ") + title, fontWeight = FontWeight.Medium,
                color = if (ok) Color(0xFF2E9E5B) else MaterialTheme.colorScheme.error)
            Text(desc, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        if (!ok) Button(onClick) { Text(button) } else OutlinedButton(onClick) { Text("Open") }
    }
}

@Composable
private fun SliderRow(label: String, value: Float, range: ClosedFloatingPointRange<Float>, shown: String, onChange: (Float) -> Unit) {
    Column {
        Row { Text(label, Modifier.weight(1f)); Text(shown, color = MaterialTheme.colorScheme.onSurfaceVariant) }
        Slider(value, onChange, valueRange = range)
    }
}

@Composable
private fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f)); Switch(checked, onChange)
    }
}

@Composable
private fun SettingsScreen(tick: Int, askBt: () -> Unit) {
    val ctx = LocalContext.current
    val s by Prefs.settings.collectAsState()
    fun set(f: (PillSettings) -> PillSettings) = Prefs.update(f)

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("Dynamic Pill", fontSize = 28.sp, fontWeight = FontWeight.Bold)

        Section("1 · Setup") {
            SetupRow("Accessibility service", "Draws the pill over the camera. It never reads your screen.",
                remember(tick) { Setup.a11y(ctx) }, "Enable") { Setup.open(ctx, Settings.ACTION_ACCESSIBILITY_SETTINGS) }
            SetupRow("Notification access", "Notifications, calls, timers, alarms, navigation and music controls.",
                remember(tick) { Setup.notif(ctx) }, "Enable") { Setup.open(ctx, Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS) }
            SetupRow("Bluetooth permission", "Shows the name of the device that connects.",
                remember(tick) { Setup.bt(ctx) }, "Grant", askBt)
            SetupRow("Battery: no restrictions", "Stops MIUI from killing the pill in the background.",
                remember(tick) { Setup.battery(ctx) }, "Allow") { Setup.open(ctx, Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS) }
            if (Miui.isMiui) {
                Text("Xiaomi / MIUI", fontWeight = FontWeight.Medium)
                Text("Turn on all three, then lock the app in Recents (long-press its card → lock icon).",
                    fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                OutlinedButton({ Miui.autostart(ctx) }, Modifier.fillMaxWidth()) { Text("Autostart") }
                OutlinedButton({ Miui.batterySaver(ctx) }, Modifier.fillMaxWidth()) { Text("Battery saver → No restrictions") }
                OutlinedButton({ Miui.otherPermissions(ctx) }, Modifier.fillMaxWidth()) { Text("Other permissions → Pop-up windows in background") }
                OutlinedButton({ Miui.appInfo(ctx) }, Modifier.fillMaxWidth()) { Text("App info (Android 13: ⋮ → Allow restricted settings)") }
            }
        }

        Section("2 · Try it") {
            Text("Needs the accessibility service enabled.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton({
                    IslandBus.post(IslandEvent("test:n", Kind.NOTIFICATION, "Marco", "Ci vediamo alle 8 al solito posto?",
                        compact = "Marco", ttlMs = 7000, sourceApp = "Messages", reply = {}, open = {}, dismiss = {}))
                }) { Text("Message") }
                OutlinedButton({
                    IslandBus.post(IslandEvent("test:call", Kind.CALL, "Giulia", "Incoming call", compact = "Calling", autoExpand = true,
                        actions = listOf(
                            EventAction("Decline", style = Style.DESTRUCTIVE) { IslandBus.remove("test:call") },
                            EventAction("Answer", style = Style.POSITIVE) { IslandBus.remove("test:call") })))
                }) { Text("Call") }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton({
                    IslandBus.post(IslandEvent("test:timer", Kind.TIMER, "Timer", "Pasta", compact = "",
                        chronoWhen = System.currentTimeMillis() + 90_000, chronoDown = true, ttlMs = 30_000,
                        actions = listOf(EventAction("Stop", style = Style.DESTRUCTIVE) { IslandBus.remove("test:timer") })))
                }) { Text("Timer") }
                OutlinedButton({
                    IslandBus.post(IslandEvent("test:media", Kind.MEDIA, "Song title", "Artist", playing = true, ttlMs = 20_000,
                        actions = listOf(EventAction(glyph = Glyph.PREV) {}, EventAction(glyph = Glyph.PAUSE) {}, EventAction(glyph = Glyph.NEXT) {})))
                }) { Text("Music") }
                OutlinedButton({
                    IslandBus.post(IslandEvent("test:bt", Kind.BLUETOOTH, "Earbuds", "Connected", compact = "Connected", ttlMs = 4000))
                }) { Text("BT") }
            }
        }

        Section("3 · Appearance") {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("System", "Light", "Dark").forEachIndexed { i, l ->
                    FilterChip(s.theme == i, { set { it.copy(theme = i) } }, { Text(l) })
                }
            }
            SwitchRow("Show idle pill around the camera", s.showIdle) { v -> set { it.copy(showIdle = v) } }
            SliderRow("Compact width", s.widthDp.toFloat(), 150f..260f, "${s.widthDp} dp") { v -> set { it.copy(widthDp = v.toInt()) } }
            SliderRow("Height", s.heightDp.toFloat(), 28f..48f, "${s.heightDp} dp") { v -> set { it.copy(heightDp = v.toInt()) } }
            SliderRow("Corner radius", s.cornerDp.toFloat(), 8f..48f, "${s.cornerDp} dp") { v -> set { it.copy(cornerDp = v.toInt()) } }
            SliderRow("Horizontal offset", s.xOffsetDp.toFloat(), -40f..40f, "${s.xOffsetDp} dp") { v -> set { it.copy(xOffsetDp = v.toInt()) } }
            SliderRow("Vertical offset", s.yOffsetDp.toFloat(), -10f..30f, "${s.yOffsetDp} dp") { v -> set { it.copy(yOffsetDp = v.toInt()) } }
            SliderRow("Transparency (opacity)", s.alpha, 0.3f..1f, "${(s.alpha * 100).toInt()}%") { v -> set { it.copy(alpha = v) } }
            SliderRow("Animation speed", s.animSpeed, 0.5f..2f, "%.1fx".format(s.animSpeed)) { v -> set { it.copy(animSpeed = v) } }
            Text("Colour", fontWeight = FontWeight.Medium)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                FilterChip(!s.useCustomColor, { set { it.copy(useCustomColor = false) } }, { Text("Auto") })
                listOf(0xFF000000, 0xFF1F2430, 0xFFFF6900, 0xFF1E5BFF, 0xFF0B8F5A, 0xFF6A3DF0, 0xFFFFFFFF).forEach { c ->
                    val argb = c.toInt()
                    Box(
                        Modifier.size(32.dp).clip(CircleShape).background(Color(argb))
                            .border(if (s.useCustomColor && s.colorArgb == argb) 3.dp else 1.dp,
                                if (s.useCustomColor && s.colorArgb == argb) MaterialTheme.colorScheme.primary else Color.Gray, CircleShape)
                            .clickable { set { it.copy(useCustomColor = true, colorArgb = argb) } }
                    )
                }
            }
            var hex by remember { mutableStateOf("") }
            OutlinedTextField(hex, {
                hex = it.trim().removePrefix("#")
                if (hex.length == 6) hex.toLongOrNull(16)?.let { v -> set { p -> p.copy(useCustomColor = true, colorArgb = (0xFF000000 or v).toInt()) } }
            }, label = { Text("Custom colour (hex, e.g. 1A237E)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        }

        Section("4 · What to show") {
            Kind.values().forEach { k ->
                SwitchRow(k.label, s.enabled(k)) { on -> set { it.copy(disabled = if (on) it.disabled - k.key else it.disabled + k.key) } }
            }
            SwitchRow("Interact with notifications (reply, actions, dismiss)", s.interactive) { v -> set { it.copy(interactive = v) } }
            SliderRow("Auto-collapse after", s.autoCollapseSec.toFloat(), 3f..15f, "${s.autoCollapseSec} s") { v -> set { it.copy(autoCollapseSec = v.toInt()) } }
            var blocked by remember { mutableStateOf(s.blocked.joinToString(",")) }
            OutlinedTextField(blocked, {
                blocked = it
                set { p -> p.copy(blocked = it.split(',').map { x -> x.trim() }.filter { x -> x.isNotEmpty() }.toSet()) }
            }, label = { Text("Muted apps (package names, comma separated)") }, modifier = Modifier.fillMaxWidth())
        }

        Section("5 · Gemini") {
            Text("Tap the idle pill to type a question, or long-press it for the voice assistant. Typed questions use your own " +
                "Google AI Studio API key (aistudio.google.com/apikey). Only the text you send is sent to Google.",
                fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            OutlinedTextField(s.geminiKey, { v -> set { it.copy(geminiKey = v.trim()) } }, label = { Text("Gemini API key") },
                singleLine = true, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
            OutlinedTextField(s.geminiModel, { v -> set { it.copy(geminiModel = v.trim()) } }, label = { Text("Model name") },
                singleLine = true, modifier = Modifier.fillMaxWidth())
        }
        Spacer(Modifier.height(24.dp))
    }
}
