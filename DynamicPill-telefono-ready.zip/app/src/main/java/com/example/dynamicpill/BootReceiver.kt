package com.example.dynamicpill

import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.service.notification.NotificationListenerService

/** MIUI sometimes forgets to bind the notification listener after boot/update; ask for a rebind. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        try {
            NotificationListenerService.requestRebind(ComponentName(context, IslandNotificationListener::class.java))
        } catch (_: Exception) {
        }
    }
}
