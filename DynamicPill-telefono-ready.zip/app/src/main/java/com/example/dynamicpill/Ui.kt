package com.example.dynamicpill

import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.StateFlow

// ====================================================================== shared geometry / mode logic

enum class Mode { HIDDEN, IDLE, COMPACT, EXPANDED }

/** Camera cut-out geometry measured at runtime (works for the Redmi Note 10 Pro punch-hole and any other device). */
data class Geo(
    val cutWdp: Float = 26f, val cutHdp: Float = 26f,
    val centerXpx: Float = 540f, val centerYpx: Float = 50f,
    val screenWdp: Float = 392f, val screenWpx: Int = 1080,
    val portrait: Boolean = true
)

interface IslandHost {
    fun askGemini(prompt: String)
    fun openGemini()
    fun closeGemini()
    fun launchAssistant()
    fun openShade()
    fun collapse()
    fun setInput(active: Boolean)
    fun touch()
}

fun pillHeightDp(s: PillSettings, geo: Geo) = maxOf(s.heightDp.toFloat(), geo.cutHdp + 6f)
fun compactWidthDp(s: PillSettings, geo: Geo) = maxOf(s.widthDp.toFloat(), geo.cutWdp + 96f)
fun expandedWidthDp(geo: Geo) = minOf(geo.screenWdp - 16f, 372f)

fun islandMode(top: IslandEvent?, expanded: Boolean, gem: GeminiState, s: PillSettings, geo: Geo): Mode = when {
    !geo.portrait -> Mode.HIDDEN
    gem.open || (expanded && top != null) -> Mode.EXPANDED
    top != null -> Mode.COMPACT
    s.showIdle -> Mode.IDLE
    else -> Mode.HIDDEN
}

/** Height of the expanded content below the camera band. The service uses this to size the overlay window. */
fun contentHeightDp(top: IslandEvent?, gem: GeminiState, s: PillSettings): Float {
    if (gem.open) return if (gem.loading || gem.answer.isNotEmpty()) 236f else 66f
    return when (top?.kind) {
        Kind.MEDIA -> 118f
        Kind.CALL -> 112f
        Kind.NOTIFICATION -> if (s.interactive) 150f else 112f
        Kind.TIMER, Kind.ALARM -> 142f
        Kind.CHARGING, Kind.BATTERY -> 118f
        Kind.BLUETOOTH -> 72f
        Kind.NAVIGATION -> 118f
        null -> 66f
    }
}

// ====================================================================== palette

private val Orange = Color(0xFFFF6900)
private val GeminiBlue = Color(0xFF8AB4F8)

data class Pal(val bg: Color, val fg: Color, val sub: Color, val chip: Color)

fun palette(s: PillSettings, dark: Boolean): Pal {
    val bg = when {
        s.useCustomColor -> Color(s.colorArgb)
        dark -> Color.Black
        else -> Color(0xFFF2F2F5)
    }
    val fg = if (bg.luminance() > 0.5f) Color(0xFF111114) else Color.White
    return Pal(bg, fg, fg.copy(alpha = .64f), fg.copy(alpha = .11f))
}

fun accentOf(k: Kind) = when (k) {
    Kind.CALL -> Color(0xFF2ECC71)
    Kind.ALARM, Kind.TIMER -> Color(0xFFFFA000)
    Kind.NAVIGATION -> Color(0xFF4C8DFF)
    Kind.NOTIFICATION -> Orange
    Kind.BLUETOOTH -> Color(0xFF3D8BFF)
    Kind.CHARGING -> Color(0xFF3DDC84)
    Kind.BATTERY -> Color(0xFFFF5252)
    Kind.MEDIA -> Color(0xFFB388FF)
}

@Composable
private fun Modifier.tap(onClick: () -> Unit): Modifier =
    clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = onClick)

// ====================================================================== root

@Composable
fun IslandRoot(host: IslandHost, geoFlow: StateFlow<Geo>) {
    val s by Prefs.settings.collectAsState()
    val events by IslandBus.events.collectAsState()
    val expanded by IslandBus.expanded.collectAsState()
    val gem by IslandBus.gemini.collectAsState()
    val geo by geoFlow.collectAsState()
    val top = events.firstOrNull()
    val topNow by rememberUpdatedState(top)

    val mode = islandMode(top, expanded, gem, s, geo)
    val dark = when (s.theme) { 1 -> false; 2 -> true; else -> androidx.compose.foundation.isSystemInDarkTheme() }
    val pal = palette(s, dark)
    val pillH = pillHeightDp(s, geo)

    val tw = when (mode) {
        Mode.HIDDEN -> geo.cutWdp
        Mode.IDLE -> geo.cutWdp + 14f
        Mode.COMPACT -> compactWidthDp(s, geo)
        Mode.EXPANDED -> expandedWidthDp(geo)
    }
    val th = if (mode == Mode.EXPANDED) pillH + contentHeightDp(top, gem, s) else pillH

    // One spring drives size and shape: smooth, slightly elastic, speed scales with the user's setting.
    val spec = spring<Dp>(dampingRatio = 0.74f, stiffness = 420f * s.animSpeed)
    val w by animateDpAsState(tw.dp, spec, label = "w")
    val h by animateDpAsState(th.dp, spec, label = "h")
    val r by animateDpAsState(minOf(s.cornerDp.toFloat(), th / 2f).dp, spec, label = "r")
    val vis by animateFloatAsState(if (mode == Mode.HIDDEN) 0f else 1f, tween((240 / s.animSpeed).toInt()), label = "vis")

    val gestures = if (mode == Mode.IDLE || mode == Mode.COMPACT) {
        Modifier
            .pointerInput(mode) {
                detectTapGestures(
                    onTap = { if (mode == Mode.IDLE) host.openGemini() else { IslandBus.expanded.value = true; host.touch() } },
                    onLongPress = { if (mode == Mode.IDLE) host.launchAssistant() else topNow?.open?.invoke() }
                )
            }
            .pointerInput(mode) {
                var dy = 0f
                detectVerticalDragGestures(
                    onDragStart = { dy = 0f },
                    onDragEnd = { if (dy > 36f) host.openShade() },       // swipe down = pull the shade, like a normal status bar
                    onVerticalDrag = { _, d -> dy += d }
                )
            }
    } else {
        Modifier.pointerInput(Unit) {
            var dy = 0f
            detectVerticalDragGestures(
                onDragStart = { dy = 0f },
                onDragEnd = { if (dy < -48f) host.collapse() },
                onVerticalDrag = { _, d -> dy += d }
            )
        }
    }

    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
        val shape = RoundedCornerShape(r)
        Box(
            Modifier.size(w, h)
                .graphicsLayer { alpha = vis }
                .clip(shape)
                .background(pal.bg.copy(alpha = s.alpha))
                .border(0.5.dp, pal.fg.copy(alpha = .10f), shape)
                .then(gestures),
            contentAlignment = Alignment.TopCenter
        ) {
            Crossfade(targetState = Pair(mode, if (gem.open) "gem" else top?.id), animationSpec = tween(160), label = "content") { (m, _) ->
                when {
                    m == Mode.EXPANDED -> Expanded(top, gem, s, pal, geo, host, pillH)
                    m == Mode.COMPACT && top != null -> CompactContent(top, pal, geo, compactWidthDp(s, geo), pillH)
                }
            }
        }
    }
}

// ====================================================================== compact

@Composable
private fun CompactContent(ev: IslandEvent, pal: Pal, geo: Geo, w: Float, h: Float) {
    Row(Modifier.requiredSize(w.dp, h.dp).padding(horizontal = 9.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.weight(1f), contentAlignment = Alignment.CenterStart) { Badge(ev, 20.dp) }
        Spacer(Modifier.width((geo.cutWdp + 8f).dp))                    // keeps the camera hole clear
        Box(Modifier.weight(1f), contentAlignment = Alignment.CenterEnd) {
            when {
                ev.kind == Kind.MEDIA && ev.playing -> Equalizer(accentOf(Kind.MEDIA))
                ev.chronoWhen > 0 -> ChronoText(ev, 12.sp, pal.fg, FontWeight.Medium)
                else -> Text(ev.compact, color = pal.fg, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
    }
}

@Composable
private fun Equalizer(color: Color) {
    val t = rememberInfiniteTransition(label = "eq")
    Row(Modifier.height(16.dp), horizontalArrangement = Arrangement.spacedBy(2.dp), verticalAlignment = Alignment.Bottom) {
        listOf(420, 560, 480).forEachIndexed { i, d ->
            val f by t.animateFloat(0.25f, 1f, infiniteRepeatable(tween(d, easing = LinearEasing), RepeatMode.Reverse), label = "b$i")
            Box(Modifier.width(3.dp).fillMaxHeight(f).clip(RoundedCornerShape(2.dp)).background(color))
        }
    }
}

@Composable
private fun ChronoText(ev: IslandEvent, size: TextUnit, color: Color, weight: FontWeight = FontWeight.Normal) {
    var now by remember(ev.id) { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(ev.id) { while (true) { now = System.currentTimeMillis(); delay(1000 - now % 1000) } }  // ticks only while visible
    val ms = if (ev.chronoDown) maxOf(0L, ev.chronoWhen - now) else maxOf(0L, now - ev.chronoWhen)
    val sec = ms / 1000
    val txt = if (sec >= 3600) "%d:%02d:%02d".format(sec / 3600, sec % 3600 / 60, sec % 60) else "%02d:%02d".format(sec / 60, sec % 60)
    Text(txt, color = color, fontSize = size, fontWeight = weight)
}

@Composable
private fun Badge(ev: IslandEvent, size: Dp) {
    val accent = accentOf(ev.kind)
    val img = remember(ev.icon) { ev.icon?.asImageBitmap() }
    when {
        img != null && !ev.iconMono ->
            Image(img, null, Modifier.size(size).clip(RoundedCornerShape(size * 0.28f)), contentScale = ContentScale.Crop)
        img != null ->
            Box(Modifier.size(size).clip(CircleShape).background(accent), Alignment.Center) {
                Image(img, null, Modifier.size(size * 0.62f), colorFilter = ColorFilter.tint(Color.White))
            }
        else ->
            Box(Modifier.size(size).clip(CircleShape).background(accent.copy(alpha = .22f)), Alignment.Center) {
                KindIcon(ev.kind, accent, size * 0.64f)
            }
    }
}

// ====================================================================== expanded

private fun bandLabel(ev: IslandEvent?, gem: GeminiState) = when {
    gem.open -> "Gemini"
    ev == null -> ""
    else -> when (ev.kind) {
        Kind.MEDIA -> "Now playing"; Kind.CALL -> "Phone"; Kind.ALARM -> "Alarm"; Kind.TIMER -> "Timer"
        Kind.NAVIGATION -> "Navigation"; Kind.BLUETOOTH -> "Bluetooth"; Kind.CHARGING -> "Charging"
        Kind.BATTERY -> "Battery"; Kind.NOTIFICATION -> ev.sourceApp.ifBlank { "Notification" }
    }
}

@Composable
private fun Expanded(ev: IslandEvent?, gem: GeminiState, s: PillSettings, pal: Pal, geo: Geo, host: IslandHost, pillH: Float) {
    Box(
        Modifier.requiredSize(expandedWidthDp(geo).dp, (pillH + contentHeightDp(ev, gem, s)).dp)
            .pointerInput(Unit) { awaitPointerEventScope { while (true) { awaitPointerEvent(PointerEventPass.Initial); host.touch() } } }
    ) {
        // Camera band: label on the left, close button on the right, camera hole in the middle.
        Row(Modifier.fillMaxWidth().height(pillH.dp).padding(horizontal = 14.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.weight(1f)) { Text(bandLabel(ev, gem), color = pal.sub, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis) }
            Spacer(Modifier.width((geo.cutWdp + 8f).dp))
            Box(Modifier.weight(1f), contentAlignment = Alignment.CenterEnd) {
                Box(Modifier.size(24.dp).clip(CircleShape).background(pal.chip).tap { host.collapse() }, Alignment.Center) {
                    GlyphIcon(Glyph.CLOSE, pal.fg, 12.dp)
                }
            }
        }
        Column(Modifier.fillMaxSize().padding(start = 16.dp, end = 16.dp, top = (pillH + 2f).dp, bottom = 12.dp)) {
            when {
                gem.open -> GeminiPanel(gem, pal, host)
                ev == null -> {}
                else -> when (ev.kind) {
                    Kind.MEDIA -> MediaBody(ev, pal)
                    Kind.CALL -> CallBody(ev, pal)
                    Kind.NOTIFICATION -> NotificationBody(ev, s, pal, host)
                    Kind.TIMER, Kind.ALARM -> TimerBody(ev, pal, host)
                    Kind.CHARGING, Kind.BATTERY -> BatteryBody(ev, pal)
                    Kind.BLUETOOTH -> Header(ev, pal, true)
                    Kind.NAVIGATION -> NavBody(ev, pal, host)
                }
            }
        }
    }
}

@Composable
private fun Header(ev: IslandEvent, pal: Pal, big: Boolean = false, showText: Boolean = true) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Badge(ev, if (big) 44.dp else 38.dp)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(ev.title, color = pal.fg, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (showText && ev.text.isNotBlank())
                Text(ev.text, color = pal.sub, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

@Composable
private fun Chip(text: String, pal: Pal, style: Style = Style.NEUTRAL, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val bg = when (style) { Style.POSITIVE -> Color(0xFF2ECC71); Style.DESTRUCTIVE -> Color(0xFFFF4D4D); Style.NEUTRAL -> pal.chip }
    val fg = if (style == Style.NEUTRAL) pal.fg else Color.White
    Box(modifier.height(36.dp).clip(RoundedCornerShape(18.dp)).background(bg).tap(onClick).padding(horizontal = 14.dp), Alignment.Center) {
        Text(text, color = fg, fontSize = 13.sp, fontWeight = FontWeight.Medium, maxLines = 1)
    }
}

@Composable
private fun ColumnScope.MediaBody(ev: IslandEvent, pal: Pal) {
    Header(ev, pal, big = true)
    Spacer(Modifier.weight(1f))
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
        ev.actions.forEach { a ->
            val main = a.glyph == Glyph.PLAY || a.glyph == Glyph.PAUSE
            Box(
                Modifier.size(if (main) 48.dp else 40.dp).clip(CircleShape)
                    .background(if (main) accentOf(Kind.MEDIA) else pal.chip).tap { a.run() },
                Alignment.Center
            ) { a.glyph?.let { GlyphIcon(it, if (main) Color.White else pal.fg, 20.dp) } }
        }
    }
}

@Composable
private fun ColumnScope.CallBody(ev: IslandEvent, pal: Pal) {
    Header(ev, pal, big = true)
    Spacer(Modifier.weight(1f))
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        if (ev.actions.isEmpty()) Chip("Open", pal, Style.POSITIVE, Modifier.weight(1f)) { ev.open?.invoke() }
        else ev.actions.take(2).forEach { a -> Chip(a.label, pal, a.style, Modifier.weight(1f), a.run) }
    }
}

@Composable
private fun NotificationBody(ev: IslandEvent, s: PillSettings, pal: Pal, host: IslandHost) {
    var replying by remember(ev.id) { mutableStateOf(false) }
    LaunchedEffect(replying) { host.setInput(replying) }                    // window becomes focusable only while typing
    DisposableEffect(ev.id) { onDispose { host.setInput(false) } }

    Column(Modifier.fillMaxSize().then(if (s.interactive) Modifier else Modifier.tap { ev.open?.invoke(); host.collapse() })) {
        Header(ev, pal, showText = false)
        if (ev.text.isNotBlank())
            Text(ev.text, color = pal.fg, fontSize = 13.sp, maxLines = if (s.interactive) 2 else 3, overflow = TextOverflow.Ellipsis,
                modifier = Modifier.padding(top = 6.dp))
        Spacer(Modifier.weight(1f))
        if (s.interactive) {
            if (replying) {
                InputRow("Reply…", pal, accentOf(Kind.NOTIFICATION)) { ev.reply?.invoke(it); replying = false; host.collapse() }
            } else {
                Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (ev.reply != null) Chip("Reply", pal, Style.NEUTRAL) { replying = true }
                    ev.actions.take(2).forEach { a -> Chip(a.label, pal, a.style) { a.run(); host.collapse() } }
                    Chip("Ask Gemini", pal) {
                        host.askGemini("Suggest one short, friendly reply to this message from ${ev.title}: \"${ev.text}\"")
                    }
                    Chip("Open", pal) { ev.open?.invoke(); host.collapse() }
                    ev.dismiss?.let { d -> Chip("Dismiss", pal) { d(); IslandBus.remove(ev.id); host.collapse() } }
                }
            }
        }
    }
}

@Composable
private fun ColumnScope.TimerBody(ev: IslandEvent, pal: Pal, host: IslandHost) {
    Header(ev, pal, showText = true)
    Spacer(Modifier.weight(1f))
    if (ev.chronoWhen > 0) ChronoText(ev, 30.sp, pal.fg, FontWeight.Bold)
    Spacer(Modifier.height(6.dp))
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        ev.actions.take(2).forEach { a -> Chip(a.label, pal, a.style, Modifier.weight(1f)) { a.run(); if (ev.kind == Kind.ALARM) host.collapse() } }
        if (ev.actions.isEmpty()) Chip("Open", pal, Style.NEUTRAL, Modifier.weight(1f)) { ev.open?.invoke(); host.collapse() }
    }
}

@Composable
private fun ColumnScope.BatteryBody(ev: IslandEvent, pal: Pal) {
    val bat by IslandBus.battery.collectAsState()
    val accent = accentOf(if (bat.charging || bat.full) Kind.CHARGING else Kind.BATTERY)
    val frac by animateFloatAsState((bat.level.coerceAtLeast(0)) / 100f, tween(500), label = "bat")
    Row(verticalAlignment = Alignment.CenterVertically) {
        KindIcon(ev.kind, accent, 30.dp)
        Spacer(Modifier.width(10.dp))
        Text("${bat.level.coerceAtLeast(0)}%", color = pal.fg, fontSize = 34.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.width(14.dp))
        Column {
            Text(when { bat.full -> "Fully charged"; bat.charging -> "Charging · ${bat.plug}"; else -> "Battery low" },
                color = pal.fg, fontSize = 14.sp, fontWeight = FontWeight.Medium)
            Text("%.1f °C".format(bat.tempC), color = pal.sub, fontSize = 12.sp)
        }
    }
    Spacer(Modifier.weight(1f))
    Box(Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)).background(pal.chip)) {
        Box(Modifier.fillMaxWidth(frac).fillMaxHeight().clip(RoundedCornerShape(4.dp)).background(accent))
    }
}

@Composable
private fun ColumnScope.NavBody(ev: IslandEvent, pal: Pal, host: IslandHost) {
    Header(ev, pal, big = true)
    Spacer(Modifier.weight(1f))
    Chip("Open navigation", pal) { ev.open?.invoke(); host.collapse() }
}

// ====================================================================== Gemini

@Composable
private fun ColumnScope.GeminiPanel(gem: GeminiState, pal: Pal, host: IslandHost) {
    LaunchedEffect(Unit) { host.setInput(true) }
    DisposableEffect(Unit) { onDispose { host.setInput(false) } }
    Row(verticalAlignment = Alignment.CenterVertically) {
        InputRow("Ask Gemini…", pal, GeminiBlue, Modifier.weight(1f)) { host.askGemini(it) }
        Spacer(Modifier.width(8.dp))
        Chip("Voice", pal) { host.launchAssistant() }
    }
    when {
        gem.loading -> {
            val a by rememberInfiniteTransition(label = "think").animateFloat(0.3f, 1f, infiniteRepeatable(tween(700), RepeatMode.Reverse), label = "a")
            Row(Modifier.padding(top = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                SparkleIcon(GeminiBlue.copy(alpha = a), 18.dp)
                Spacer(Modifier.width(8.dp))
                Text("Thinking…", color = pal.sub, fontSize = 13.sp)
            }
        }
        gem.answer.isNotEmpty() ->
            Text(gem.answer, color = pal.fg, fontSize = 13.sp, lineHeight = 18.sp,
                modifier = Modifier.padding(top = 12.dp).weight(1f).verticalScroll(rememberScrollState()))
    }
}

@Composable
private fun InputRow(hint: String, pal: Pal, accent: Color, modifier: Modifier = Modifier, onSend: (String) -> Unit) {
    var q by remember { mutableStateOf("") }
    val focus = remember { FocusRequester() }
    val kb = LocalSoftwareKeyboardController.current
    LaunchedEffect(Unit) { delay(250); try { focus.requestFocus(); kb?.show() } catch (_: Exception) {} }
    val send = { if (q.isNotBlank()) { onSend(q.trim()); q = "" } }
    Row(
        modifier.fillMaxWidth().height(40.dp).clip(RoundedCornerShape(20.dp)).background(pal.chip).padding(start = 14.dp, end = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.weight(1f)) {
            if (q.isEmpty()) Text(hint, color = pal.sub, fontSize = 14.sp)
            BasicTextField(
                q, { q = it }, Modifier.fillMaxWidth().focusRequester(focus), singleLine = true,
                textStyle = TextStyle(color = pal.fg, fontSize = 14.sp), cursorBrush = SolidColor(accent),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send), keyboardActions = KeyboardActions(onSend = { send() })
            )
        }
        Box(Modifier.size(32.dp).clip(CircleShape).background(accent).tap { send() }, Alignment.Center) {
            GlyphIcon(Glyph.PLAY, Color.Black, 14.dp)
        }
    }
}

// ====================================================================== original vector icons (drawn, no assets)

@Composable
fun KindIcon(kind: Kind, tint: Color, sz: Dp = 20.dp) {
    when (kind) {
        Kind.CALL -> Icon(Icons.Filled.Call, null, Modifier.size(sz), tint)
        Kind.NOTIFICATION -> Icon(Icons.Filled.Notifications, null, Modifier.size(sz), tint)
        else -> Canvas(Modifier.size(sz)) {
            val w = size.width
            val st = Stroke(width = w * 0.1f, cap = StrokeCap.Round, join = StrokeJoin.Round)
            when (kind) {
                Kind.BLUETOOTH -> drawPath(Path().apply {
                    moveTo(.3f * w, .3f * w); lineTo(.7f * w, .7f * w); lineTo(.5f * w, .9f * w)
                    lineTo(.5f * w, .1f * w); lineTo(.7f * w, .3f * w); lineTo(.3f * w, .7f * w)
                }, tint, style = st)
                Kind.CHARGING -> drawPath(Path().apply {
                    moveTo(.58f * w, .05f * w); lineTo(.25f * w, .55f * w); lineTo(.47f * w, .55f * w)
                    lineTo(.40f * w, .95f * w); lineTo(.75f * w, .4f * w); lineTo(.53f * w, .4f * w); close()
                }, tint)
                Kind.BATTERY -> {
                    drawRoundRect(tint, Offset(.12f * w, .3f * w), Size(.66f * w, .4f * w), CornerRadius(.06f * w), style = st)
                    drawRect(tint, Offset(.82f * w, .43f * w), Size(.07f * w, .14f * w))
                }
                Kind.ALARM, Kind.TIMER -> {
                    drawCircle(tint, .38f * w, Offset(.5f * w, .5f * w), style = st)
                    drawLine(tint, Offset(.5f * w, .5f * w), Offset(.5f * w, .28f * w), st.width, StrokeCap.Round)
                    drawLine(tint, Offset(.5f * w, .5f * w), Offset(.66f * w, .5f * w), st.width, StrokeCap.Round)
                }
                Kind.NAVIGATION -> drawPath(Path().apply {
                    moveTo(.5f * w, .08f * w); lineTo(.85f * w, .9f * w); lineTo(.5f * w, .72f * w); lineTo(.15f * w, .9f * w); close()
                }, tint)
                Kind.MEDIA -> {
                    drawCircle(tint, .17f * w, Offset(.36f * w, .75f * w))
                    drawLine(tint, Offset(.52f * w, .75f * w), Offset(.52f * w, .16f * w), st.width, StrokeCap.Round)
                    drawLine(tint, Offset(.52f * w, .16f * w), Offset(.82f * w, .3f * w), st.width, StrokeCap.Round)
                }
                else -> {}
            }
        }
    }
}

@Composable
private fun SparkleIcon(tint: Color, sz: Dp) = Canvas(Modifier.size(sz)) {
    val w = size.width
    drawPath(Path().apply {
        moveTo(.5f * w, 0f); quadraticBezierTo(.5f * w, .5f * w, w, .5f * w)
        quadraticBezierTo(.5f * w, .5f * w, .5f * w, w); quadraticBezierTo(.5f * w, .5f * w, 0f, .5f * w)
        quadraticBezierTo(.5f * w, .5f * w, .5f * w, 0f); close()
    }, tint)
}

@Composable
private fun GlyphIcon(g: Glyph, tint: Color, sz: Dp) = Canvas(Modifier.size(sz)) {
    val w = size.width
    when (g) {
        Glyph.PLAY -> drawPath(Path().apply { moveTo(.28f * w, .15f * w); lineTo(.85f * w, .5f * w); lineTo(.28f * w, .85f * w); close() }, tint)
        Glyph.PAUSE -> {
            drawRoundRect(tint, Offset(.22f * w, .16f * w), Size(.2f * w, .68f * w), CornerRadius(.04f * w))
            drawRoundRect(tint, Offset(.58f * w, .16f * w), Size(.2f * w, .68f * w), CornerRadius(.04f * w))
        }
        Glyph.NEXT -> {
            drawPath(Path().apply { moveTo(.15f * w, .2f * w); lineTo(.7f * w, .5f * w); lineTo(.15f * w, .8f * w); close() }, tint)
            drawRect(tint, Offset(.74f * w, .2f * w), Size(.12f * w, .6f * w))
        }
        Glyph.PREV -> {
            drawPath(Path().apply { moveTo(.85f * w, .2f * w); lineTo(.3f * w, .5f * w); lineTo(.85f * w, .8f * w); close() }, tint)
            drawRect(tint, Offset(.14f * w, .2f * w), Size(.12f * w, .6f * w))
        }
        Glyph.CLOSE -> {
            drawLine(tint, Offset(.2f * w, .2f * w), Offset(.8f * w, .8f * w), .14f * w, StrokeCap.Round)
            drawLine(tint, Offset(.8f * w, .2f * w), Offset(.2f * w, .8f * w), .14f * w, StrokeCap.Round)
        }
    }
}
