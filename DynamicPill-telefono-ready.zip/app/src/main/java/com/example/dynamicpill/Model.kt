package com.example.dynamicpill

import android.app.ActivityOptions
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.os.Build
import android.os.Handler
import android.os.Looper
import kotlinx.coroutines.flow.MutableStateFlow

/** Event categories. `rank` decides which one wins when several are active. */
enum class Kind(val key: String, val label: String, val rank: Int) {
    CALL("call", "Calls", 9), ALARM("alarm", "Alarms", 8), TIMER("timer", "Timers", 7),
    NAVIGATION("nav", "Navigation", 6), NOTIFICATION("notif", "Notifications", 5),
    BLUETOOTH("bt", "Bluetooth", 4), CHARGING("charge", "Charging", 3),
    BATTERY("battery", "Battery", 2), MEDIA("media", "Music", 1)
}

enum class Glyph { PREV, PLAY, PAUSE, NEXT, CLOSE }
enum class Style { NEUTRAL, POSITIVE, DESTRUCTIVE }

data class EventAction(
    val label: String = "",
    val glyph: Glyph? = null,
    val style: Style = Style.NEUTRAL,
    val run: () -> Unit
)

data class IslandEvent(
    val id: String,
    val kind: Kind,
    val title: String,
    val text: String = "",
    val compact: String = "",            // short text shown beside the camera in compact mode
    val icon: Bitmap? = null,
    val iconMono: Boolean = false,       // true = monochrome small icon, tinted white on an accent circle
    val ttlMs: Long = 0,                 // 0 = sticky until removed, >0 = auto-dismiss
    val autoExpand: Boolean = false,
    val actions: List<EventAction> = emptyList(),
    val open: (() -> Unit)? = null,
    val reply: ((String) -> Unit)? = null,
    val dismiss: (() -> Unit)? = null,
    val chronoWhen: Long = 0,            // wall-clock base of a chronometer notification
    val chronoDown: Boolean = false,
    val playing: Boolean = false,
    val sourceApp: String = "",
    val posted: Long = System.currentTimeMillis()
)

data class BatteryInfo(
    val level: Int = -1, val charging: Boolean = false, val plug: String = "",
    val tempC: Float = 0f, val full: Boolean = false
)

data class GeminiState(val open: Boolean = false, val loading: Boolean = false, val answer: String = "")

data class PillSettings(
    val theme: Int = 0,                  // 0 system, 1 light, 2 dark
    val widthDp: Int = 190,
    val heightDp: Int = 34,
    val xOffsetDp: Int = 0,
    val yOffsetDp: Int = 0,
    val cornerDp: Int = 40,
    val useCustomColor: Boolean = false,
    val colorArgb: Int = 0xFF000000.toInt(),
    val alpha: Float = 1f,
    val animSpeed: Float = 1f,
    val showIdle: Boolean = true,
    val interactive: Boolean = true,
    val autoCollapseSec: Int = 6,
    val disabled: Set<String> = emptySet(),
    val blocked: Set<String> = emptySet(),
    val geminiKey: String = "",
    val geminiModel: String = "gemini-2.5-flash"
) {
    fun enabled(k: Kind) = k.key !in disabled
}

object Prefs {
    private var sp: SharedPreferences? = null
    val settings = MutableStateFlow(PillSettings())

    fun init(ctx: Context) {
        if (sp != null) return
        val p = ctx.applicationContext.getSharedPreferences("pill", Context.MODE_PRIVATE)
        sp = p
        settings.value = load(p)
    }

    fun update(f: (PillSettings) -> PillSettings) {
        val n = f(settings.value)
        settings.value = n
        sp?.let { save(it, n) }
    }

    private fun set(p: String?) = p.orEmpty().split(',').map { it.trim() }.filter { it.isNotEmpty() }.toSet()

    private fun load(p: SharedPreferences): PillSettings {
        val d = PillSettings()
        return d.copy(
            theme = p.getInt("theme", d.theme), widthDp = p.getInt("w", d.widthDp),
            heightDp = p.getInt("h", d.heightDp), xOffsetDp = p.getInt("x", d.xOffsetDp),
            yOffsetDp = p.getInt("y", d.yOffsetDp), cornerDp = p.getInt("r", d.cornerDp),
            useCustomColor = p.getBoolean("cc", d.useCustomColor), colorArgb = p.getInt("col", d.colorArgb),
            alpha = p.getFloat("alpha", d.alpha), animSpeed = p.getFloat("speed", d.animSpeed),
            showIdle = p.getBoolean("idle", d.showIdle), interactive = p.getBoolean("inter", d.interactive),
            autoCollapseSec = p.getInt("auto", d.autoCollapseSec),
            disabled = set(p.getString("dis", "")), blocked = set(p.getString("blk", "")),
            geminiKey = p.getString("gk", "").orEmpty(), geminiModel = p.getString("gm", d.geminiModel).orEmpty()
        )
    }

    private fun save(p: SharedPreferences, s: PillSettings) {
        p.edit()
            .putInt("theme", s.theme).putInt("w", s.widthDp).putInt("h", s.heightDp)
            .putInt("x", s.xOffsetDp).putInt("y", s.yOffsetDp).putInt("r", s.cornerDp)
            .putBoolean("cc", s.useCustomColor).putInt("col", s.colorArgb)
            .putFloat("alpha", s.alpha).putFloat("speed", s.animSpeed)
            .putBoolean("idle", s.showIdle).putBoolean("inter", s.interactive)
            .putInt("auto", s.autoCollapseSec)
            .putString("dis", s.disabled.joinToString(",")).putString("blk", s.blocked.joinToString(","))
            .putString("gk", s.geminiKey).putString("gm", s.geminiModel)
            .apply()
    }
}

/** In-process event hub shared by the notification listener, the accessibility service and the UI. Main-thread only. */
object IslandBus {
    private val main = Handler(Looper.getMainLooper())
    private val map = LinkedHashMap<String, IslandEvent>()
    private val timers = HashMap<String, Runnable>()

    val events = MutableStateFlow<List<IslandEvent>>(emptyList())
    val expanded = MutableStateFlow(false)
    val inputActive = MutableStateFlow(false)
    val touch = MutableStateFlow(0L)
    val gemini = MutableStateFlow(GeminiState())
    val battery = MutableStateFlow(BatteryInfo())

    private fun onMain(block: () -> Unit) {
        if (Looper.myLooper() == Looper.getMainLooper()) block() else main.post(block)
    }

    fun post(e: IslandEvent) = onMain {
        if (!Prefs.settings.value.enabled(e.kind)) return@onMain
        val prev = map[e.id]
        val ev = if (prev != null && e.ttlMs == 0L) e.copy(posted = prev.posted) else e
        map[ev.id] = ev
        timers.remove(ev.id)?.let { main.removeCallbacks(it) }
        if (ev.ttlMs > 0) {
            val r = Runnable { remove(ev.id) }
            timers[ev.id] = r
            main.postDelayed(r, ev.ttlMs)
        }
        publish()
        if (ev.autoExpand && prev == null) expanded.value = true
    }

    fun remove(id: String) = onMain {
        timers.remove(id)?.let { main.removeCallbacks(it) }
        if (map.remove(id) != null) {
            publish()
            if (map.isEmpty()) expanded.value = false
        }
    }

    private fun rank(e: IslandEvent): Int {
        val tier = when {
            e.kind == Kind.CALL || e.kind == Kind.ALARM -> 3000
            e.ttlMs > 0 -> 2000
            else -> 1000
        }
        return tier + e.kind.rank
    }

    private fun publish() {
        events.value = map.values.sortedWith(compareByDescending<IslandEvent> { rank(it) }.thenByDescending { it.posted })
    }
}

/** Sends a PendingIntent, opting in to background activity starts on Android 14+. */
fun sendPi(ctx: Context, pi: PendingIntent?, fill: Intent? = null) {
    if (pi == null) return
    try {
        val opts = if (Build.VERSION.SDK_INT >= 34)
            ActivityOptions.makeBasic()
                .setPendingIntentBackgroundActivityStartMode(ActivityOptions.MODE_BACKGROUND_ACTIVITY_START_ALLOWED)
                .toBundle()
        else null
        pi.send(ctx, 0, fill, null, null, null, opts)
    } catch (_: PendingIntent.CanceledException) {
    }
}

fun IslandBus.collapseState() {
    expanded.value = false
    inputActive.value = false
    gemini.value = GeminiState()
}
