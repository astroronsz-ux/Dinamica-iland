package com.example.dynamicpill

import android.content.ActivityNotFoundException
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings

/** Shortcuts into Xiaomi's security-center screens. Each one falls back to the standard App Info page. */
object Miui {
    val isMiui: Boolean
        get() = Build.MANUFACTURER.equals("xiaomi", true) || Build.MANUFACTURER.equals("redmi", true) ||
            Build.BRAND.equals("xiaomi", true) || Build.BRAND.equals("redmi", true) || Build.BRAND.equals("poco", true)

    private fun Context.start(i: Intent): Boolean = try {
        startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); true
    } catch (_: Exception) { false }

    fun appInfo(ctx: Context) = ctx.start(
        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${ctx.packageName}"))
    )

    fun autostart(ctx: Context) {
        val i = Intent().setComponent(ComponentName("com.miui.securitycenter",
            "com.miui.permcenter.autostart.AutoStartManagementActivity"))
        if (!ctx.start(i)) appInfo(ctx)
    }

    fun batterySaver(ctx: Context) {
        val i = Intent().setComponent(ComponentName("com.miui.powerkeeper",
            "com.miui.powerkeeper.ui.HiddenAppsConfigActivity"))
            .putExtra("package_name", ctx.packageName).putExtra("package_label", "Dynamic Pill")
        if (!ctx.start(i)) appInfo(ctx)
    }

    /** "Other permissions" page: contains "Display pop-up windows while running in the background". */
    fun otherPermissions(ctx: Context) {
        val i = Intent("miui.intent.action.APP_PERM_EDITOR")
            .setClassName("com.miui.securitycenter", "com.miui.permcenter.permissions.PermissionsEditorActivity")
            .putExtra("extra_pkgname", ctx.packageName)
        if (!ctx.start(i)) appInfo(ctx)
    }
}
