package com.example.dynamicpill

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/**
 * Minimal Gemini REST client (Google AI Studio API key). Single-shot: no conversation memory,
 * no streaming, no extra libraries -> tiny RAM/APK footprint.
 */
object GeminiClient {
    private const val SYSTEM = "You answer inside a tiny phone overlay. Reply in plain text, no markdown, max about 70 words."

    suspend fun ask(key: String, model: String, prompt: String): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            require(key.isNotBlank()) { "Add your Gemini API key in the app settings first." }
            val body = JSONObject()
                .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", SYSTEM))))
                .put("contents", JSONArray().put(JSONObject().put("role", "user")
                    .put("parts", JSONArray().put(JSONObject().put("text", prompt)))))
            val url = URL("https://generativelanguage.googleapis.com/v1beta/models/${model.trim()}:generateContent")
            val conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"; connectTimeout = 10_000; readTimeout = 30_000; doOutput = true
                setRequestProperty("Content-Type", "application/json")
                setRequestProperty("x-goog-api-key", key.trim())
            }
            conn.outputStream.use { it.write(body.toString().toByteArray()) }
            val code = conn.responseCode
            val txt = (if (code in 200..299) conn.inputStream else conn.errorStream).bufferedReader().use { it.readText() }
            if (code !in 200..299) error(JSONObject(txt).optJSONObject("error")?.optString("message") ?: "HTTP $code")
            JSONObject(txt).getJSONArray("candidates").getJSONObject(0)
                .getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text").trim()
        }
    }
}
