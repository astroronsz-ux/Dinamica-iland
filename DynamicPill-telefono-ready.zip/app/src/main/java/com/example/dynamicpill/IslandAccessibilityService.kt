package com.example.dynamicpill

import android.accessibilityservice.AccessibilityService
import android.bluetooth.BluetoothDevice
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.res.Configuration
import android.graphics.PixelFormat
import android.os.BatteryManager
import android.os.SystemClock
import android.util.Log
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.view.WindowManager.LayoutParams.*
import android.view.accessibility.AccessibilityEvent
import android.widget.FrameLayout
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.platform.ViewCompositionStrategy
import androidx.core.content.ContextCompat
import androidx.core.content.IntentCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LifecycleRegistry
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.savedstate.SavedStateRegistry
import androidx.savedstate.SavedStateRegistryController
import androidx.savedstate.SavedStateRegistryOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.roundToInt

/** Minimal lifecycle so Compose can run inside a Service-owned window. */
class ServiceOwner : LifecycleOwner, SavedStateRegistryOwner {
    private val reg = LifecycleRegistry(this)
    private val ssc = SavedStateRegistryController.create(this)
    override val lifecycle: Lifecycle get() = reg
    override val savedStateRegistry: SavedStateRegistry get() = ssc.savedStateRegistry
    fun create() { ssc.performAttach(); ssc.performRestore(null); reg.currentState = Lifecycle.State.CREATED }
    fun resume() { reg.currentState = Lifecycle.State.RESUMED }
    fun destroy() { reg.currentState = Lifecycle.State.DESTROYED }
}

/** Root view: reports taps outside the pill so an expanded island can collapse. */
class RootFrame(ctx: Context, private val onOutside: () -> Unit) : FrameLayout(ctx) {
    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        if (ev.actionMasked == MotionEvent.ACTION_OUTSIDE) { onOutside(); return false }
        return super.dispatchTouchEvent(ev)
    }
}

private data class Slot(
    val w: Int = 1, val h: Int = 1, val x: Int = 0, val y: Int = 0,
    val touchable: Boolean = false, val focusable: Boolean = false
)
private data class Ins(val top: IslandEvent?, val ex: Boolean, val g: GeminiState, val s: PillSettings, val inp: Boolean)
private data class AutoIns(val ex: Boolean, val g: GeminiState, val inp: Boolean, val kind: Kind?)

class IslandAccessibilityService : AccessibilityService(), IslandHost {

    companion object { @Volatile var running = false }

    private val BASE = FLAG_NOT_TOUCH_MODAL or FLAG_LAYOUT_IN_SCREEN or FLAG_LAYOUT_NO_LIMITS or FLAG_WATCH_OUTSIDE_TOUCH

    private lateinit var wm: WindowManager
    private lateinit var lp: WindowManager.LayoutParams
    private var owner = ServiceOwner()
    private var scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var frame: RootFrame? = null
    private var attached = false
    private var cur = Slot()
    private var geminiJob: Job? = null
    private val geoFlow = MutableStateFlow(Geo())

    // ------------------------------------------------------------------ lifecycle

    override fun onServiceConnected() {
        super.onServiceConnected()
        running = true
        wm = getSystemService(WindowManager::class.java)
        owner = ServiceOwner().also { it.create() }
        scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
        updateGeo()

        val f = RootFrame(this) { if (IslandBus.expanded.value || IslandBus.gemini.value.open) collapse() }
        f.setViewTreeLifecycleOwner(owner)
        f.setViewTreeSavedStateRegistryOwner(owner)
        val cv = ComposeView(this).apply {
            setViewCompositionStrategy(ViewCompositionStrategy.DisposeOnDetachedFromWindow)
            setContent { IslandRoot(this@IslandAccessibilityService, geoFlow) }
        }
        f.addView(cv, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
        frame = f

        lp = WindowManager.LayoutParams(1, 1, TYPE_ACCESSIBILITY_OVERLAY, BASE or FLAG_NOT_TOUCHABLE or FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            layoutInDisplayCutoutMode = LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            softInputMode = SOFT_INPUT_ADJUST_NOTHING
            title = "DynamicPill"
        }
        owner.resume()
        registerSources()
        startCollectors()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        if (frame != null) updateGeo()
    }

    override fun onUnbind(intent: Intent?): Boolean { cleanup(); return super.onUnbind(intent) }
    override fun onDestroy() { cleanup(); super.onDestroy() }

    private fun cleanup() {
        if (!running) return
        running = false
        scope.cancel()
        try { unregisterReceiver(receiver) } catch (_: Exception) {}
        frame?.let { if (attached) try { wm.removeView(it) } catch (_: Exception) {} }
        attached = false; frame = null
        owner.destroy()
        IslandBus.collapseState()
    }

    // ------------------------------------------------------------------ geometry (camera cut-out)

    private fun updateGeo() {
        val d = resources.displayMetrics.density
        val m = wm.currentWindowMetrics
        val b = m.bounds
        val r = m.windowInsets.displayCutout?.boundingRects?.firstOrNull { it.top <= 1 && it.width() < b.width() / 2 }
        geoFlow.value = Geo(
            cutWdp = r?.let { it.width() / d } ?: 26f,
            cutHdp = r?.let { it.height() / d } ?: 26f,
            centerXpx = r?.exactCenterX() ?: (b.width() / 2f),
            centerYpx = r?.exactCenterY() ?: (18f * d),
            screenWdp = b.width() / d, screenWpx = b.width(),
            portrait = b.height() > b.width()
        )
    }

    // ------------------------------------------------------------------ window management

    private fun startCollectors() {
        // 1) Window size / position / touchability follows the UI state.
        scope.launch {
            val inputs = combine(IslandBus.events, IslandBus.expanded, IslandBus.gemini, Prefs.settings, IslandBus.inputActive) { ev, ex, g, s, inp ->
                Ins(ev.firstOrNull(), ex, g, s, inp)
            }
            combine(inputs, geoFlow) { i, geo -> slotFor(i, geo) }
                .distinctUntilChanged()
                .collectLatest { applySlot(it) }
        }
        // 2) Auto-collapse after inactivity (calls and alarms stay open until handled).
        scope.launch {
            combine(IslandBus.expanded, IslandBus.gemini, IslandBus.inputActive, IslandBus.events, IslandBus.touch) { ex, g, inp, ev, _ ->
                AutoIns(ex, g, inp, ev.firstOrNull()?.kind)
            }.collectLatest { a ->
                when {
                    a.g.open -> if (!a.g.loading) { delay(60_000); collapse() }
                    a.ex && !a.inp && a.kind != Kind.CALL && a.kind != Kind.ALARM -> {
                        delay(Prefs.settings.value.autoCollapseSec * 1000L)
                        IslandBus.expanded.value = false
                    }
                }
            }
        }
    }

    private fun slotFor(i: Ins, geo: Geo): Slot {
        val d = resources.displayMetrics.density
        val mode = islandMode(i.top, i.ex, i.g, i.s, geo)
        val pillH = pillHeightDp(i.s, geo)
        val (wDp, hDp) = when (mode) {
            Mode.HIDDEN -> 1f to 1f
            Mode.IDLE -> (geo.cutWdp + 14f) to pillH
            Mode.COMPACT -> compactWidthDp(i.s, geo) to pillH
            Mode.EXPANDED -> expandedWidthDp(geo) to (pillH + contentHeightDp(i.top, i.g, i.s))
        }
        return Slot(
            w = ceil(wDp * d).toInt(), h = ceil(hDp * d).toInt(),
            x = (geo.centerXpx - geo.screenWpx / 2f + i.s.xOffsetDp * d).roundToInt(),
            y = max(0f, geo.centerYpx - pillH * d / 2f + i.s.yOffsetDp * d).roundToInt(),
            touchable = mode != Mode.HIDDEN,
            focusable = i.inp && mode == Mode.EXPANDED
        )
    }

    /** Grow immediately; shrink only after the contraction animation has finished, so nothing gets clipped. */
    private suspend fun applySlot(t: Slot) {
        val f = frame ?: return
        val grows = t.w > cur.w || t.h > cur.h
        val shrinks = t.w < cur.w || t.h < cur.h
        if (attached && shrinks && !grows) {
            delay((450f / Prefs.settings.value.animSpeed).toLong().coerceIn(220L, 900L))
        }
        var flags = BASE
        if (!t.touchable) flags = flags or FLAG_NOT_TOUCHABLE
        if (!t.focusable) flags = flags or FLAG_NOT_FOCUSABLE
        lp.width = t.w; lp.height = t.h; lp.x = t.x; lp.y = t.y; lp.flags = flags
        try {
            if (attached) wm.updateViewLayout(f, lp) else { wm.addView(f, lp); attached = true }
        } catch (e: Exception) { Log.w("DynamicPill", "window update failed", e) }
        cur = t
    }

    // ------------------------------------------------------------------ IslandHost

    override fun touch() { IslandBus.touch.value = SystemClock.uptimeMillis() }
    override fun setInput(active: Boolean) { IslandBus.inputActive.value = active }
    override fun openGemini() { IslandBus.gemini.value = GeminiState(open = true) }
    override fun closeGemini() = collapse()
    override fun openShade() { performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS) }

    override fun collapse() {
        geminiJob?.cancel()
        IslandBus.collapseState()
    }

    override fun askGemini(prompt: String) {
        val s = Prefs.settings.value
        IslandBus.gemini.value = GeminiState(open = true, loading = true)
        geminiJob?.cancel()
        geminiJob = scope.launch {
            val r = GeminiClient.ask(s.geminiKey, s.geminiModel, prompt)
            IslandBus.gemini.value = GeminiState(open = true, loading = false,
                answer = r.getOrElse { "⚠ ${it.message ?: "Gemini request failed"}" })
        }
    }

    override fun launchAssistant() {
        collapse()
        try {
            startActivity(Intent(Intent.ACTION_ASSIST).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (_: Exception) {
            packageManager.getLaunchIntentForPackage("com.google.android.apps.bard")
                ?.let { startActivity(it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        }
    }

    // ------------------------------------------------------------------ battery + Bluetooth sources

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            when (i.action) {
                Intent.ACTION_BATTERY_CHANGED -> onBattery(i)
                BluetoothDevice.ACTION_ACL_CONNECTED -> onBluetooth(i, true)
                BluetoothDevice.ACTION_ACL_DISCONNECTED -> onBluetooth(i, false)
            }
        }
    }

    private fun registerSources() {
        val f = IntentFilter().apply {
            addAction(Intent.ACTION_BATTERY_CHANGED)
            addAction(BluetoothDevice.ACTION_ACL_CONNECTED)
            addAction(BluetoothDevice.ACTION_ACL_DISCONNECTED)
        }
        ContextCompat.registerReceiver(this, receiver, f, ContextCompat.RECEIVER_EXPORTED)
    }

    private fun onBattery(i: Intent) {
        val lvl = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
        if (lvl < 0 || scale <= 0) return
        val pct = lvl * 100 / scale
        val plugged = i.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0)
        val full = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1) == BatteryManager.BATTERY_STATUS_FULL
        val plug = when {
            plugged and BatteryManager.BATTERY_PLUGGED_WIRELESS != 0 -> "Wireless"
            plugged and BatteryManager.BATTERY_PLUGGED_AC != 0 -> "AC charger"
            plugged and BatteryManager.BATTERY_PLUGGED_USB != 0 -> "USB"
            else -> ""
        }
        val old = IslandBus.battery.value
        val now = BatteryInfo(pct, plugged != 0, plug, i.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) / 10f, full)
        if (now == old) return
        IslandBus.battery.value = now
        if (old.level < 0) return                       // first sticky broadcast: just store it
        when {
            now.charging && !old.charging ->
                IslandBus.post(IslandEvent("charge", Kind.CHARGING, "Charging", "$plug · $pct%", compact = "$pct%", ttlMs = 5000))
            !now.charging && old.charging -> IslandBus.remove("charge")
            now.full && !old.full ->
                IslandBus.post(IslandEvent("charge", Kind.CHARGING, "Fully charged", "$pct%", compact = "100%", ttlMs = 5000))
            !now.charging && pct <= 20 && old.level > 20 ->
                IslandBus.post(IslandEvent("battery", Kind.BATTERY, "Battery low", "$pct% remaining", compact = "$pct%", ttlMs = 7000))
        }
    }

    private fun onBluetooth(i: Intent, connected: Boolean) {
        val dev = IntentCompat.getParcelableExtra(i, BluetoothDevice.EXTRA_DEVICE, BluetoothDevice::class.java) ?: return
        val name = try { dev.name } catch (_: SecurityException) { null } ?: "Bluetooth device"
        IslandBus.post(IslandEvent("bt:${dev.address}", Kind.BLUETOOTH, name,
            if (connected) "Connected" else "Disconnected", compact = if (connected) "Connected" else "Off", ttlMs = 4000))
    }
}
